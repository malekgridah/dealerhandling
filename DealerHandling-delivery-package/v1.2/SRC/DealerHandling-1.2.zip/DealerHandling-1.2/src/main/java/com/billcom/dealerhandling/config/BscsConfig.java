package com.billcom.dealerhandling.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author malek.gridah
 */

@Configuration
@ComponentScan("com.billcom.connectionpools")
public class BscsConfig {}
