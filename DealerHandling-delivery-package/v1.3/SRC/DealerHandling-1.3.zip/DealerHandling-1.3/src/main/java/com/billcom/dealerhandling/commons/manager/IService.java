package com.billcom.dealerhandling.commons.manager;

public interface IService {
	

}
