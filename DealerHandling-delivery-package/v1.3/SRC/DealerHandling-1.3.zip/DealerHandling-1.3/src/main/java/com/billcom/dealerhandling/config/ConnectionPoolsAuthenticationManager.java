package com.billcom.dealerhandling.config;

import com.billcom.connectionpools.config.AES128PasswordEncoder;
import com.billcom.connectionpools.config.properties.ServerConnectionSettings;
import com.lhs.ccb.cfw.cda.utility.GlobalUserProperties;
import com.lhs.ccb.cfw.cda.utility.UserPropertiesFacade;
import com.lhs.ccb.cfw.wcs.security.JaasAuthenticationProvider;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author malek.gridah
 * @since 1.3
 */

@Log4j2
@Component
public class ConnectionPoolsAuthenticationManager implements AuthenticationManager {

    private final AES128PasswordEncoder aes128PasswordEncoder;
    private final ServerConnectionSettings serverConnectionSettings;

    static final List<GrantedAuthority> AUTHORITIES = new ArrayList<>();

    @Autowired
    public ConnectionPoolsAuthenticationManager(AES128PasswordEncoder aes128PasswordEncoder,
                                                ServerConnectionSettings serverConnectionSettings) {
        this.aes128PasswordEncoder = aes128PasswordEncoder;
        this.serverConnectionSettings = serverConnectionSettings;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        JaasAuthenticationProvider localJaasAuthenticationProvider = new JaasAuthenticationProvider();

        try {
            Boolean decryptPassword = Optional.ofNullable(serverConnectionSettings.getEncryption().getHeaders().getEnabled())
                    .orElse(false);
            String password = (String) authentication.getCredentials();
            if (decryptPassword) {
                password = aes128PasswordEncoder.decode(password);
            }
            localJaasAuthenticationProvider.authenticateUser(authentication.getName(),
                    password, new Object[]{null});
            GlobalUserProperties localGlobalUserProperties = new GlobalUserProperties();
            UserPropertiesFacade.instance().setProperties(localGlobalUserProperties);
            UserPropertiesFacade.instance().setUserAttribute("AuthenticationProvider", localJaasAuthenticationProvider);
            return new UsernamePasswordAuthenticationToken(authentication.getName(),
                    authentication.getCredentials(), AUTHORITIES);
        } catch (Exception e) {
            throw new BadCredentialsException("Bad Credentials");
        }
    }

}

